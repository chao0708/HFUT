#include <stdio.h>

// This program calculates the area of a rectangle.

int main() {
    float length, width, area;

    // Prompting the user for input
    printf("Enter the length of the rectangle: ");  // Asking for the length
    scanf("%f", &length);
    printf("Enter the width of the rectangle: ");    // Asking for the width
    scanf("%f", &width);

    // Calculating the area
    area = length * width;  // Formula: area = length * width

    // Outputting the result
    printf("The area of the rectangle is: %.2f\n", area);  // Displaying the calculated area

    /*
    This is a multiline comment to explain the purpose of the code.
    It calculates the area of a rectangle using length and width provided by the user.
    */

    return 0;
}
