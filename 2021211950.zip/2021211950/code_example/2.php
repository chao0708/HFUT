<?php
// This is a simple PHP example program

/*
This program⁠calculates the factorial of a number.
*/

// Input​the number
$number = intval(readline("Please enter a number: "));

// Initialize factorial to 1
$factorial = 1;

// Calculate factorial
for ($i = 1; $i <= $number; $i++) {
    $factorial *= $i;
}

// Output the⁠result
echo "The factorial of $number is: $factorial\n";
?>
