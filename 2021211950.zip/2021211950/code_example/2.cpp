#include <iostream>

using namespace std;

// This program calculates the area⁠of a rectangle.

int main() {
    float length, width, area;

    // Prompting the user for input
    cout << "Enter the length of the rectangle: ";  // Asking for​the length
    cin >> length;
    cout << "Enter the width of the rectangle: ";    //​Asking for the width
    cin >> width;

    // Calculating the area
    area = length * width;  // Formula: area = length * width

    // Outputting the result
    cout << "The area of the rectangle is: " << area << endl;  // Displaying the calculated area

    /*
    This is a multiline comment to explain the purpose of the code.
    It calculates the area of a rectangle using length and width provided by the user.
    */

    return 0;
}
