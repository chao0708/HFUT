# This program calculates the area of a rectangle.

length = float(input("Enter the length of the rectangle: "))  # Asking for the length
width = float(input("Enter the width of the rectangle: "))    # Asking for the width

# Calculating the area
area = length * width  # Formula: area = length * width

# Outputting the result
print("The area of the rectangle is:", area)  # Displaying the calculated area

"""
This is a multiline comment to explain the purpose of the code.
It calculates the area of a rectangle using length and width provided by the user.
"""
