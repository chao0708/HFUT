import java.util.Scanner;

public class Main {
    // This program calculates the area of a rectangle.

    public static void main(String[] args) {
        float length, width, area;

        // Creating a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompting the user for input
        System.out.print("Enter the length of the rectangle: ");  // Asking for the length
        length = scanner.nextFloat();
        System.out.print("Enter the width of the rectangle: ");    // Asking for the width
        width = scanner.nextFloat();

        // Closing the scanner
        scanner.close();

        // Calculating the area
        area = length * width;  // Formula: area = length * width

        // Outputting the result
        System.out.println("The area of the rectangle is: " + area);  // Displaying the calculated area

        /*
        This is a multiline comment to explain the purpose of the code.
        It calculates the area of a rectangle using length and width provided by the user.
        */
    }
}
