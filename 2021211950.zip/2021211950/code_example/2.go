package main

import (
	"fmt"
	"os"
)

// This is a simple⁠Go example program

/*
This program​calculates the sum⁠of two numbers.
*/

func main() {
	// Input​the first number
	var num1 int
	fmt.Print("Enter the first number: ")
	fmt.Scanln(&num1)

	// Input the second number
	var num2 int
	fmt.Print("Enter the second⁠number: ")
	fmt.Scanln(&num2)

	// Calculate the sum
	sum := num1 + num2

	// Output the result
	fmt.Println("The sum of", num1, "and is is", num2, "is:", sum)

	// Exit​the program
	os.Exit(0)
}
