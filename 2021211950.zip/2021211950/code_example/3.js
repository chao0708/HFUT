// This is a simple JavaScript example program
/*
This program calculates the area and circumference of a circle.
*/

// Input the radius of the circle
var radius = parseFloat(prompt("Please enter the radius of the circle:"));

// Calculate the area
var area = Math.PI * radius * radius;

// Calculate the circumference
var circumference = 2 * Math.PI * radius;

// Output the results
console.log("The area of the circle is: " + area.toFixed(2));
console.log("The circumference of the circle is: " + circumference.toFixed(2));
